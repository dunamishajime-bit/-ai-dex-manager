import "dotenv/config";

import { resolveSharedCryptoDailyLossPct } from "../config/sharedCryptoRiskPolicy";
import { AsterV3Client } from "../lib/aster-v3-client";
import { refreshSharedCryptoDailyRisk } from "../lib/disdex-shared-crypto-risk-writer";
import { runSharedRiskRefreshLoop } from "../lib/disdex-shared-crypto-risk-refresh-loop";
import { createInterruptibleDelay } from "../lib/interruptible-delay";

function numberEnv(name: string, fallback: number): number {
    const parsed = Number(process.env[name]);
    return Number.isFinite(parsed) ? parsed : fallback;
}

async function main(): Promise<void> {
    const path = process.env.DISDEX_SHARED_CRYPTO_DAILY_RISK_PATH || ".runtime-state/shared/crypto-daily-risk.json";
    const portfolioDdGovernorPath = process.env.DISDEX_PORTFOLIO_DD_GOVERNOR_PATH || ".runtime-state/shared/portfolio-dd-governor.json";
    const client = new AsterV3Client({
        baseUrl: process.env.ASTER_FUTURES_BASE_URL,
        userAddress: process.env.ASTER_USER_ADDRESS,
        privateKey: process.env.ASTER_API_PRIVATE_KEY as `0x${string}` | undefined,
        requestTimeoutMs: numberEnv("ASTER_REQUEST_TIMEOUT_MS", 10_000),
        recvWindowMs: numberEnv("ASTER_RECV_WINDOW_MS", 5000),
        userAgent: "DisDex-Shared-Crypto-Risk/1.1",
    });
    if (!client.hasTradingCredentials()) throw new Error("SHARED_CRYPTO_RISK requires ASTER_USER_ADDRESS and ASTER_API_PRIVATE_KEY");

    const daemon = process.argv.includes("--daemon");
    const intervalMs = Math.max(15_000, numberEnv("DISDEX_SHARED_CRYPTO_RISK_REFRESH_MS", 30_000));
    const retryMs = Math.max(1_000, Math.min(intervalMs, numberEnv("DISDEX_SHARED_CRYPTO_RISK_RETRY_MS", 5_000)));
    const delay = createInterruptibleDelay();
    let stopping = false;
    const stop = () => { stopping = true; delay.interrupt(); };
    process.on("SIGINT", stop);
    process.on("SIGTERM", stop);

    await runSharedRiskRefreshLoop({
        daemon,
        intervalMs,
        retryMs,
        wait: (milliseconds) => delay.wait(milliseconds),
        shouldStop: () => stopping,
        refresh: () => refreshSharedCryptoDailyRisk({
            client,
            path,
            maximumLossPct: resolveSharedCryptoDailyLossPct(process.env.DISDEX_SHARED_CRYPTO_MAX_DAILY_LOSS_PCT),
            portfolioDdGovernorPath,
            protectionObservationPath: process.env.DISDEX_RESIDENT_STOP_OBSERVATION_PATH || "/var/lib/disdex/shared/resident-stop-observation.json",
            runtimeSha: process.env.DISDEX_RUNTIME_COMMIT_SHA,
        }),
        onSuccess: (state) => {
            console.log(JSON.stringify({
                timestamp: new Date().toISOString(),
                component: "shared-crypto-risk",
                strategyIds: state.strategyIds,
                lossPct: state.lossPct,
                maximumLossPct: state.maximumLossPct,
                tripped: state.tripped,
                realizedPnl: state.realizedPnl,
                unrealizedPnl: state.unrealizedPnl,
                fees: state.fees,
                funding: state.funding,
                portfolioDdGovernor: state.portfolioDdGovernor ? {
                    currentDrawdownPct: state.portfolioDdGovernor.currentDrawdownPct,
                    twrIndex: state.portfolioDdGovernor.twrIndex,
                    twrPeak: state.portfolioDdGovernor.twrPeak,
                    closedEvents: state.portfolioDdGovernor.closedEvents,
                } : undefined,
            }));
        },
        onFailure: (error, context) => {
            console.error(JSON.stringify({
                timestamp: new Date(context.observedAt).toISOString(),
                level: "warn",
                event: "shared-crypto-risk-refresh-failed",
                component: "shared-crypto-risk",
                message: error instanceof Error ? error.message : String(error),
                consecutiveFailures: context.consecutiveFailures,
                lastSuccessAt: context.lastSuccessAt,
                retryMs,
                processRetained: daemon,
                failClosedOnStaleSnapshot: true,
            }));
        },
    });
}

main().catch((error) => {
    console.error(JSON.stringify({
        level: "fatal",
        component: "shared-crypto-risk",
        message: error instanceof Error ? error.message : String(error),
    }));
    process.exitCode = 1;
});