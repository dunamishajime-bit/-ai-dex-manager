import assert from "node:assert/strict";
import { planUnifiedPortfolio } from "@/lib/disdex-unified-portfolio-routing";

const plan = planUnifiedPortfolio([
    { sleeve: "V12", symbol: "ETHUSDT", side: "LONG", gross: 1, notionalUsd: 1000, signalTs: 1 },
    { sleeve: "V11_EQ", symbol: "METAUSDT", side: "LONG", gross: 1, notionalUsd: 1000, signalTs: 1 },
    { sleeve: "PENGU_DUAL_LS_V2", symbol: "PENGUUSDT", side: "SHORT", gross: 1.0, notionalUsd: 1000, signalTs: 1 },
    { sleeve: "V12", symbol: "UNKNOWNUSDT", side: "LONG", gross: 1, notionalUsd: 1000, signalTs: 1 },
], []);
assert.equal(plan.accepted.length, 3);
assert.equal(plan.rejected[0].reason, "UNKNOWN_OR_SLEEVE_MISMATCH");
assert.equal(plan.totalGross, 3.0);
assert.equal(plan.cryptoGross <= 3, true);
assert.equal(plan.quality102LiveSelectorParity, false);
assert.equal(plan.quality102LiveBlockedFailClosed, true);
const top2 = planUnifiedPortfolio([
    { sleeve: "V12", symbol: "ETHUSDT", side: "LONG", gross: 1, notionalUsd: 1000, signalTs: 1 },
    { sleeve: "V12", symbol: "SOLUSDT", side: "LONG", gross: 1, notionalUsd: 1000, signalTs: 1 },
], []);
assert.deepEqual(top2.accepted.map((item) => item.gross), [1, 0.5]);
assert.equal(planUnifiedPortfolio([{ sleeve: "V12", symbol: "SOLUSDT", side: "LONG", gross: 1, notionalUsd: 1, signalTs: 1 }], [{ sleeve: "V12", symbol: "ETHUSDT", gross: 0.5 }]).accepted[0].gross, 1);
assert.equal(planUnifiedPortfolio([
    { sleeve: "V12", symbol: "AVAXUSDT", side: "LONG", gross: 0.1, notionalUsd: 100, signalTs: 1 },
], [
    { sleeve: "V12", symbol: "ETHUSDT", gross: 0.4 },
    { sleeve: "V12", symbol: "SOLUSDT", gross: 0.4 },
    { sleeve: "V12", symbol: "LINKUSDT", gross: 0.1 },
]).rejected[0].reason, "V12_MAX_POSITIONS_REACHED");
console.log("UNIFIED_PORTFOLIO_ROUTING_SELFTEST_PASS");
