import { AsterResidentStopGateway } from "../lib/venue-resident-stop";
import { findManagedOrdinaryResidentStops } from "../lib/disdex-managed-protective-orders";
import "dotenv/config";

import { readFile, rename, stat, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

import {
    QUALITY102_CAUSAL_V1,
    resolveQuality102CausalV1Runtime,
    type Quality102CausalV1Mode,
} from "../config/disdexQuality102CausalV1Runtime";
import {
    QUALITY102_CAUSAL_V4_CAPABILITIES,
    QUALITY102_CAUSAL_V4_S34_MODEL,
} from "../config/disdexQuality102CausalV4Model";
import { resolveSharedCryptoDailyLossPct } from "../config/sharedCryptoRiskPolicy";
import { AsterV3Client, isAsterDepositRequirementError } from "../lib/aster-v3-client";
import { classifyAsterRateBudgetFailure } from "../lib/disdex-aster-rate-budget-policy";
import { AsterDirectTradeExecutor, type DirectOpenOrder, type DirectPosition } from "../lib/direct-trade-executor";
import { FileAccountOrderLock } from "../lib/disdex-account-order-lock";
import { createInterruptibleDelay } from "../lib/interruptible-delay";
import { nextQuality102DaemonWaitMs } from "../lib/quality102-live-scheduling";
import { readQuality102CausalV1Ownership } from "../lib/disdex-quality102-causal-v1-ownership";
import {
    FileQuality102CausalV1StateStore,
    type Quality102CausalV1State,
} from "../lib/disdex-quality102-causal-v1-state";
import { Quality102CausalV1AsterMarketDataProvider } from "../lib/disdex-quality102-causal-v1-market-data";
import { Quality102CausalV1Runner } from "../lib/disdex-quality102-causal-v1-runner";
import { buildQuality102CausalV4Signal } from "../lib/disdex-quality102-causal-v4-signal";
import { buildQuality102CausalV4DecisionSnapshot } from "../lib/disdex-quality102-causal-v4-observability";
import { SignedPaperDirectTradeExecutor } from "../lib/signed-paper-direct-trade-executor";
import { V12AsterLiveAdapter } from "../lib/v12-aster-live-adapter";
import { classifyAsterSymbol } from "../lib/disdex-aster-portfolio-classifier";
import { findManagedV12ProtectiveOrders, findManagedV12V4ProtectiveOrders, findManagedFetBrk48ProtectiveOrders, findManagedIdlePriorityShortProtectiveOrders } from "../lib/disdex-managed-protective-orders";

const SHA_PATTERN = /^[0-9a-f]{40}$/i;
const DEFAULT_STATE_ROOT = "/var/lib/disdex/quality102-causal-v1";
const DEFAULT_SHARED_ROOT = "/var/lib/disdex/shared";
const DEFAULT_MAX_DATA_AGE_MS = 5 * 60_000;
const DEFAULT_HISTORY_HOURS = 225 * 24;
const DEFAULT_MAX_ENTRY_DELAY_MS = 2 * 60 * 60_000;
const HOUR_MS = 3_600_000;

/**
 * A temporary global Aster request-budget saturation is a safe defer, not a
 * configuration or reconciliation pass.  Returning an explicit deferred
 * result lets systemd start the daemon so its normal tick loop can retry while
 * keeping all exposure mutations blocked.  Other preflight failures must
 * continue to fail closed and prevent daemon startup.
 */
export function classifyQ102PreflightRateBudgetDeferral(error: unknown): Record<string, unknown> | undefined {
    const classified = classifyAsterRateBudgetFailure(error);
    if (!classified) return undefined;
    return {
        status: "QUALITY102_CAUSAL_V1_READ_ONLY_PREFLIGHT_DEFERRED_RATE_BUDGET",
        safetyState: "DEFERRED_FAIL_CLOSED",
        reason: classified.reason,
        ...(classified.waitMs === undefined ? {} : { retryAfterMs: classified.waitMs }),
        ordersSent: 0,
        cancelSent: 0,
        positionChangesSent: 0,
        stateChanged: false,
        syntheticOrders: 0,
        testOrders: 0,
    };
}

function q102PreflightManagedProtectiveOrderShape(
    order: DirectOpenOrder,
    positions: readonly DirectPosition[],
): { position: DirectPosition; remainingQuantity: number } | undefined {
    const symbol = String(order.symbol || "").trim().toUpperCase();
    const clientOrderId = String(order.clientOrderId || "");
    if (symbol !== "PENGUUSDT" || !/^recv8-[0-9a-f]{16,36}$/i.test(clientOrderId)) return undefined;
    if (order.reduceOnly !== true || !["NEW", "PARTIALLY_FILLED"].includes(String(order.status || "").toUpperCase())) return undefined;
    if (!Number.isFinite(order.quantity) || order.quantity <= 0 || !Number.isFinite(order.executedQuantity) || order.executedQuantity < 0 || order.executedQuantity > order.quantity) return undefined;
    const position = positions.find((candidate) => candidate.symbol.toUpperCase() === symbol && Math.abs(candidate.quantity) > 1e-12);
    if (!position || !Number.isFinite(position.quantity)) return undefined;
    const expectedSide = position.quantity > 0 ? "SELL" : "BUY";
    if (order.side !== expectedSide) return undefined;
    const remainingQuantity = order.quantity - order.executedQuantity;
    const tolerance = Math.max(1e-8, Math.abs(position.quantity) * 0.01);
    if (remainingQuantity <= 1e-12 || remainingQuantity > Math.abs(position.quantity) + tolerance) return undefined;
    return { position, remainingQuantity };
}

export function isQ102PreflightManagedProtectiveOrder(
    order: DirectOpenOrder,
    positions: readonly DirectPosition[],
): boolean {
    const matched = q102PreflightManagedProtectiveOrderShape(order, positions);
    if (!matched) return false;
    return Math.abs(matched.remainingQuantity - Math.abs(matched.position.quantity))
        <= Math.max(1e-8, Math.abs(matched.position.quantity) * 0.01);
}

export function findQ102PreflightManagedProtectiveOrders(
    openOrders: readonly DirectOpenOrder[],
    positions: readonly DirectPosition[],
): DirectOpenOrder[] {
    const candidates = openOrders.map((order) => ({ order, matched: q102PreflightManagedProtectiveOrderShape(order, positions) }))
        .filter((entry): entry is { order: DirectOpenOrder; matched: { position: DirectPosition; remainingQuantity: number } } => Boolean(entry.matched));
    if (!candidates.length) return [];
    const clientOrderIds = new Set(candidates.map(({ order }) => order.clientOrderId));
    if (clientOrderIds.size !== candidates.length) return [];
    const managed = new Set<DirectOpenOrder>();
    for (const position of positions) {
        const symbol = position.symbol.toUpperCase();
        if (symbol !== "PENGUUSDT" || !Number.isFinite(position.quantity) || Math.abs(position.quantity) <= 1e-12) continue;
        const matching = candidates.filter(({ matched }) => matched.position === position);
        if (!matching.length) continue;
        const protectedQuantity = matching.reduce((sum, { matched }) => sum + matched.remainingQuantity, 0);
        const tolerance = Math.max(1e-8, Math.abs(position.quantity) * 0.01);
        if (Math.abs(protectedQuantity - Math.abs(position.quantity)) <= tolerance) {
            for (const { order } of matching) managed.add(order);
        }
    }
    return openOrders.filter((order) => managed.has(order));
}

export function findQ102PreflightAllManagedProtectiveOrders(openOrders: readonly DirectOpenOrder[], positions: readonly DirectPosition[]): DirectOpenOrder[] {
    return [...findManagedOrdinaryResidentStops(openOrders, positions), ...findQ102PreflightManagedProtectiveOrders(openOrders, positions),
        ...findManagedV12ProtectiveOrders(openOrders, positions),
        ...findManagedV12V4ProtectiveOrders(openOrders, positions),
        ...findManagedFetBrk48ProtectiveOrders(openOrders, positions),
        ...findManagedIdlePriorityShortProtectiveOrders(openOrders, positions)];
}

export interface Quality102CausalV1LiveResolvedConfig {
    mode: Quality102CausalV1Mode;
    enabled: boolean;
    liveTradingEnabled: boolean;
    liveExecutionEnabled: boolean;
    operatorArmed: boolean;
    profitFloorEnabled?: boolean;
    adoptedExitPoliciesEnabled?: boolean;
    runtimeCommitSha: string;
    expectedRuntimeCommitSha: string;
    selectorMode: string;
    highVolSymbols: string[];
    symbols: string[];
    statePath: string;
    killSwitchPath: string;
    sharedDailyRiskPath: string;
    portfolioDdGovernorPath: string;
    accountLockPath: string;
    maximumGross: number;
    cryptoGrossCap: number;
    totalGrossCap: number;
    maximumPositions: number;
    maxSlippageBps: number;
    minimumOrderNotionalUsd: number;
    maximumEntryDelayMs: number;
    maximumDailyLossPct: number;
    maxDataAgeMs: number;
    historyCachePath: string;
    historyHours: number;
    historyPageLimit: number;
    stateRoot: string;
}

function boolEnv(env: NodeJS.ProcessEnv, name: string, fallback = false): boolean {
    const raw = env[name];
    return raw === undefined ? fallback : /^(1|true|yes|on)$/i.test(raw.trim());
}

/**
 * The live daemon validates the complete causal history before it can make a
 * signal decision.  A service-start preflight must not fetch that same
 * multi-month history a second time immediately before the daemon's first
 * tick: Aster counts Kline request weight per IP.  The default remains the
 * strict historical check for manual/pre-deploy preflights; production may
 * explicitly defer it to the daemon's first tick after the account and quote
 * safety checks have passed.
 */
export function shouldRunQuality102CausalV1PreflightHistoryCheck(
    env: NodeJS.ProcessEnv = process.env,
): boolean {
    const configured = env.QUALITY102_CAUSAL_V1_PREFLIGHT_HISTORY_CHECK ?? env.PREFLIGHT_HISTORY_CHECK;
    return configured === undefined ? true : /^(1|true|yes|on)$/i.test(configured.trim());
}

function numberEnv(env: NodeJS.ProcessEnv, name: string, fallback: number): number {
    const parsed = Number(env[name]);
    return Number.isFinite(parsed) ? parsed : fallback;
}

function requiredSha(env: NodeJS.ProcessEnv): string {
    const value = String(env.DISDEX_RUNTIME_COMMIT_SHA || env.DISDEX_RELEASE_SHA || env.DISDEX_V96_RUNTIME_COMMIT_SHA || "").trim().toLowerCase();
    return value;
}

export function parseQuality102CausalV1Symbols(value: string | undefined): string[] {
    const symbols = String(value || "")
        .split(",")
        .map((item) => item.trim().toUpperCase())
        .filter(Boolean);
    const unique = [...new Set(symbols)].sort();
    if (!unique.length) throw new Error("QUALITY102_CAUSAL_V1_SYMBOLS_REQUIRED");
    if (unique.some((symbol) => symbol === "BTCUSDT" || classifyAsterSymbol(symbol).tradable)) {
        throw new Error("QUALITY102_CAUSAL_V1_SYMBOL_UNSAFE_BASE_OVERLAP");
    }
    return unique;
}

function positiveConfig(value: number, name: string): number {
    if (!Number.isFinite(value) || value <= 0) throw new Error(`${name}_MUST_BE_POSITIVE`);
    return value;
}

export function resolveQuality102CausalV1LiveConfig(env: NodeJS.ProcessEnv = process.env): Quality102CausalV1LiveResolvedConfig {
    const runtime = resolveQuality102CausalV1Runtime(env);
    const stateRoot = resolve(env.QUALITY102_CAUSAL_V1_STATE_DIR || DEFAULT_STATE_ROOT);
    const sharedRoot = resolve(env.DISDEX_SHARED_RUNTIME_ROOT || DEFAULT_SHARED_ROOT);
    const highVolSymbols = parseQuality102CausalV1Symbols(env.QUALITY102_CAUSAL_V1_SYMBOLS);
    const s34Symbols = QUALITY102_CAUSAL_V4_S34_MODEL.map((row) => row.symbol);
    const symbols = [...new Set([...highVolSymbols, ...s34Symbols])].sort();
    const runtimeSha = requiredSha(env);
    const statePath = resolve(env.QUALITY102_CAUSAL_V1_STATE_PATH || resolve(stateRoot, "state.json"));
    const killSwitchPath = resolve(
        env.QUALITY102_CAUSAL_V1_KILL_SWITCH_FILE
        || env.DISDEX_SHARED_KILL_SWITCH_FILE
        || env.DISDEX_V13D_V11EQ_V96_KILL_SWITCH_FILE
        || env.DISDEX_V52_ASTER_ONLY_KILL_SWITCH_FILE
        || resolve(sharedRoot, "kill-switch.json"),
    );
    const sharedDailyRiskPath = resolve(
        env.QUALITY102_CAUSAL_V1_DAILY_RISK_FILE
        || env.DISDEX_SHARED_CRYPTO_DAILY_RISK_PATH
        || resolve(sharedRoot, "crypto-daily-risk.json"),
    );
    const portfolioDdGovernorPath = resolve(env.DISDEX_PORTFOLIO_DD_GOVERNOR_PATH || resolve(sharedRoot, "portfolio-dd-governor.json"));
    const accountLockPath = resolve(
        env.QUALITY102_CAUSAL_V1_ACCOUNT_LOCK_PATH
        || env.DISDEX_ACCOUNT_LOCK_PATH
        || resolve(sharedRoot, "account-order.lock"),
    );
    const maxDataAgeMs = positiveConfig(numberEnv(env, "QUALITY102_CAUSAL_V1_MAX_DATA_AGE_MS", DEFAULT_MAX_DATA_AGE_MS), "QUALITY102_CAUSAL_V1_MAX_DATA_AGE_MS");
    const maximumEntryDelayMs = positiveConfig(numberEnv(env, "QUALITY102_CAUSAL_V1_MAX_ENTRY_DELAY_MS", DEFAULT_MAX_ENTRY_DELAY_MS), "QUALITY102_CAUSAL_V1_MAX_ENTRY_DELAY_MS");
    if (maximumEntryDelayMs > 6 * HOUR_MS) throw new Error("QUALITY102_CAUSAL_V1_MAX_ENTRY_DELAY_MS_TOO_LARGE");
    const historyHours = Math.floor(numberEnv(env, "QUALITY102_CAUSAL_V1_HISTORY_HOURS", DEFAULT_HISTORY_HOURS));
    const historyPageLimit = Math.floor(numberEnv(env, "QUALITY102_CAUSAL_V1_HISTORY_PAGE_LIMIT", 500));
    if (historyHours < 181 * 24 || historyPageLimit < 1 || historyPageLimit > 500) throw new Error("QUALITY102_CAUSAL_V1_HISTORY_CONFIG_INVALID");
    const config: Quality102CausalV1LiveResolvedConfig = {
        mode: runtime.mode,
        enabled: runtime.enabled,
        liveTradingEnabled: runtime.liveTradingEnabled,
        liveExecutionEnabled: runtime.liveExecutionEnabled,
        operatorArmed: runtime.operatorArmed,
        profitFloorEnabled: boolEnv(env, "QUALITY102_Q102_PROFIT_FLOOR_ENABLED", false),
        adoptedExitPoliciesEnabled: boolEnv(env, "QUALITY102_Q102_ADOPTED_EXIT_POLICIES_ENABLED", false),
        runtimeCommitSha: runtimeSha,
        expectedRuntimeCommitSha: runtimeSha,
        selectorMode: String(env.QUALITY102_CAUSAL_V1_SELECTOR_MODE || "").trim().toUpperCase(),
        highVolSymbols,
        symbols,
        statePath,
        killSwitchPath,
        sharedDailyRiskPath,
        portfolioDdGovernorPath,
        accountLockPath,
        maximumGross: runtime.maximumGross,
        cryptoGrossCap: runtime.cryptoGrossCap,
        totalGrossCap: runtime.totalGrossCap,
        maximumPositions: runtime.maximumPositions,
        maxSlippageBps: positiveConfig(numberEnv(env, "QUALITY102_CAUSAL_V1_MAX_SLIPPAGE_BPS", 35), "QUALITY102_CAUSAL_V1_MAX_SLIPPAGE_BPS"),
        minimumOrderNotionalUsd: Math.max(5, numberEnv(env, "QUALITY102_CAUSAL_V1_MIN_ORDER_NOTIONAL_USD", 5)),
        maximumEntryDelayMs,
        maximumDailyLossPct: resolveSharedCryptoDailyLossPct(env.QUALITY102_CAUSAL_V1_MAX_DAILY_LOSS_PCT),
        maxDataAgeMs,
        historyCachePath: resolve(env.QUALITY102_CAUSAL_V1_HISTORY_CACHE_PATH || resolve(stateRoot, "market-history.json")),
        historyHours,
        historyPageLimit,
        stateRoot,
    };
    if (Math.abs(config.maximumGross - QUALITY102_CAUSAL_V1.maximumGross) > 1e-12
        || Math.abs(config.cryptoGrossCap - QUALITY102_CAUSAL_V1.cryptoGrossCap) > 1e-12
        || Math.abs(config.totalGrossCap - QUALITY102_CAUSAL_V1.totalGrossCap) > 1e-12
        || config.maximumPositions !== QUALITY102_CAUSAL_V1.maximumPositions) {
        throw new Error("QUALITY102_CAUSAL_V1_GROSS_CONTRACT_MISMATCH");
    }
    return config;
}

export function assertQuality102CausalV1ReadOnlyPreflightConfiguration(
    config: Quality102CausalV1LiveResolvedConfig,
    env: NodeJS.ProcessEnv = process.env,
): void {
    if (config.mode !== "LIVE") return;
    if (!SHA_PATTERN.test(config.runtimeCommitSha)) throw new Error("QUALITY102_CAUSAL_V1_RUNTIME_COMMIT_SHA_REQUIRED");
    if (config.selectorMode !== "CAUSAL_V4") throw new Error("QUALITY102_CAUSAL_V1_SELECTOR_MODE_ACK_REQUIRED");
    if (!QUALITY102_CAUSAL_V4_CAPABILITIES.selectorImplemented
        || !QUALITY102_CAUSAL_V4_CAPABILITIES.derivedHighVolGeneratorImplemented
        || !QUALITY102_CAUSAL_V4_CAPABILITIES.s34GeneratorImplemented
        || QUALITY102_CAUSAL_V4_CAPABILITIES.s34ModelKeyCount !== 31
        || QUALITY102_CAUSAL_V4_CAPABILITIES.fixedHistoricalTradeTimestamps
        || !QUALITY102_CAUSAL_V4_CAPABILITIES.noLookaheadByConstruction) {
        throw new Error("QUALITY102_CAUSAL_V4_IMPLEMENTATION_NOT_READY");
    }
    const ack = String(env.QUALITY102_CAUSAL_V1_LIVE_ACK || "").trim().toLowerCase();
    if (ack !== config.runtimeCommitSha.toLowerCase()) throw new Error("QUALITY102_CAUSAL_V1_LIVE_ACK_MUST_MATCH_RUNTIME_SHA");
    if (config.adoptedExitPoliciesEnabled) {
        const adoptedAck = String(env.QUALITY102_Q102_ADOPTED_EXIT_POLICIES_ACK || "").trim().toLowerCase();
        if (adoptedAck !== config.runtimeCommitSha.toLowerCase()) throw new Error("QUALITY102_Q102_ADOPTED_EXIT_POLICIES_ACK_MUST_MATCH_RUNTIME_SHA");
        if (!config.profitFloorEnabled) throw new Error("QUALITY102_Q102_ADOPTED_EXIT_POLICIES_EXISTING_FLOOR_REQUIRED");
    }
    if (boolEnv(env, "QUALITY102_LIVE_SELECTOR_PARITY") || boolEnv(env, "QUALITY102_LIVE_ENABLED")) {
        throw new Error("QUALITY102_HISTORICAL_SELECTOR_FLAG_MUST_REMAIN_FAIL_CLOSED");
    }
    if (!config.killSwitchPath || !config.sharedDailyRiskPath || !config.accountLockPath) {
        throw new Error("QUALITY102_CAUSAL_V1_SHARED_SAFETY_PATHS_REQUIRED");
    }
}

export function assertQuality102CausalV1LiveActivation(
    config: Quality102CausalV1LiveResolvedConfig,
    env: NodeJS.ProcessEnv = process.env,
): void {
    if (config.mode !== "LIVE") return;
    assertQuality102CausalV1ReadOnlyPreflightConfiguration(config, env);
    if (!config.enabled || !config.liveTradingEnabled || !config.liveExecutionEnabled || !config.operatorArmed) {
        throw new Error("QUALITY102_CAUSAL_V1_LIVE_GATES_NOT_ALL_ENABLED");
    }
}

function createClient(env: NodeJS.ProcessEnv, releaseSha: string): AsterV3Client {
    return new AsterV3Client({
        baseUrl: env.ASTER_FUTURES_BASE_URL,
        userAddress: env.ASTER_USER_ADDRESS,
        privateKey: env.ASTER_API_PRIVATE_KEY as `0x${string}` | undefined,
        requestTimeoutMs: numberEnv(env, "ASTER_REQUEST_TIMEOUT_MS", 10_000),
        recvWindowMs: numberEnv(env, "ASTER_RECV_WINDOW_MS", 5000),
        userAgent: `DisDex-Quality102-CausalV1/${releaseSha ? releaseSha.slice(0, 12) : "non-live"}`,
    });
}

function actualSide(position: DirectPosition): -1 | 1 {
    if (position.positionSide === "SHORT") return -1;
    if (position.positionSide === "LONG") return 1;
    return position.quantity < 0 ? -1 : 1;
}

function assertFreshPosition(position: DirectPosition, now: number, maxAgeMs: number): void {
    if (!Number.isFinite(position.updatedAt) || position.updatedAt <= 0 || position.updatedAt > now || now - position.updatedAt > maxAgeMs) {
        throw new Error(`QUALITY102_PREFLIGHT_POSITION_STALE:${position.symbol}`);
    }
    if (!Number.isFinite(position.quantity) || !Number.isFinite(position.entryPrice) || !Number.isFinite(position.markPrice) || !Number.isFinite(position.notionalUsd)) {
        throw new Error(`QUALITY102_PREFLIGHT_POSITION_INVALID:${position.symbol}`);
    }
}

async function stateFileExists(path: string): Promise<boolean> {
    try {
        return (await stat(path)).isFile();
    } catch {
        return false;
    }
}

async function stateFileSnapshot(path: string): Promise<string | undefined> {
    try {
        return await readFile(path, "utf8");
    } catch (error) {
        const code = error && typeof error === "object" && "code" in error
            ? String((error as { code?: unknown }).code)
            : "";
        if (code === "ENOENT") return undefined;
        throw error;
    }
}

export async function runQuality102CausalV1ReadOnlyPreflight(
    env: NodeJS.ProcessEnv = process.env,
): Promise<Record<string, unknown>> {
    const config = resolveQuality102CausalV1LiveConfig(env);
    assertQuality102CausalV1ReadOnlyPreflightConfiguration(config, env);
    if (config.mode !== "LIVE") {
        return {
            status: "QUALITY102_CAUSAL_V1_NON_LIVE_PREFLIGHT_PASS",

            mode: config.mode,
            selectorMode: config.selectorMode,
            highVolSymbols: config.highVolSymbols,
            symbols: config.symbols,
            networkReads: 0,
            ordersSent: 0,
            cancelSent: 0,
            positionChangesSent: 0,
            stateChanged: false,
            syntheticOrders: 0,
            testOrders: 0,
        };
    }
    const client = createClient(env, config.runtimeCommitSha);
    if (!client.hasTradingCredentials()) throw new Error("QUALITY102_PREFLIGHT_ASTER_CREDENTIALS_MISSING");
    const executor = new AsterDirectTradeExecutor(client, {
        exchangeInfoTtlMs: numberEnv(env, "ASTER_EXCHANGE_INFO_TTL_MS", 15 * 60_000),
        reconciliationAttempts: numberEnv(env, "ASTER_ORDER_RECONCILE_ATTEMPTS", 6),
        reconciliationDelayMs: numberEnv(env, "ASTER_ORDER_RECONCILE_DELAY_MS", 1500),
    });
    const stateStore = new FileQuality102CausalV1StateStore(config.statePath, config.mode, config.expectedRuntimeCommitSha);
    const beforeStateFile = await stateFileSnapshot(config.statePath);
    const beforeState = await stateStore.load();
    if (beforeState.pending) throw new Error("QUALITY102_PREFLIGHT_PENDING_ORDER_REQUIRES_RECONCILIATION");
    if (config.mode === "LIVE" && beforeState.runtimeCommitSha.toLowerCase() !== config.runtimeCommitSha.toLowerCase()) {
        throw new Error("QUALITY102_PREFLIGHT_STATE_SHA_MISMATCH");
    }
    const marketData = new Quality102CausalV1AsterMarketDataProvider(client, {
        symbols: config.symbols,
        historyHours: config.historyHours,
        pageLimit: config.historyPageLimit,
        cacheTtlMs: 0,
    });
    const [ping, exchangeInfo, account, positions, openOrders] = await Promise.all([
        client.ping(),
        client.getExchangeInfo(),
        executor.getAccountSnapshot(),
        executor.getPositions(),
        executor.getOpenOrders(),
    ]);
    // Establish the local freshness boundary only after the read batch has
    // completed. Account freshness uses the venue clock, so capturing `now`
    // before the network round-trip can incorrectly classify a healthy
    // snapshot as being a few milliseconds in the future.
    const now = Date.now();
    void ping;
    const exchangeRows = new Map(exchangeInfo.symbols.map((row) => [row.symbol.toUpperCase(), row]));
    for (const symbol of config.symbols) {
        const row = exchangeRows.get(symbol);
        if (!row || row.status !== "TRADING") throw new Error(`QUALITY102_PREFLIGHT_SYMBOL_NOT_TRADING:${symbol}`);
    }
    if (!(account.walletBalance > 0) || !Number.isFinite(account.availableBalance) || account.availableBalance < 0 || !Number.isFinite(account.updatedAt) || account.updatedAt <= 0 || account.updatedAt > now || now - account.updatedAt > config.maxDataAgeMs) {
        throw new Error("QUALITY102_PREFLIGHT_ACCOUNT_STALE_OR_INVALID");
    }
    const stateMatches = (position: DirectPosition) => Boolean(beforeState.position
        && beforeState.position.symbol.toUpperCase() === position.symbol.toUpperCase()
        && beforeState.position.side === actualSide(position)
        && Math.abs(beforeState.position.quantity - Math.abs(position.quantity)) <= Math.max(1e-8, beforeState.position.quantity * 0.01));
    for (const position of positions) {
        assertFreshPosition(position, now, config.maxDataAgeMs);
        const symbol = position.symbol.toUpperCase();
        if (Math.abs(position.quantity) <= 1e-12) continue;
        if (stateMatches(position)) continue;
        if (!classifyAsterSymbol(symbol).tradable) throw new Error(`QUALITY102_PREFLIGHT_UNKNOWN_POSITION_OWNERSHIP:${symbol}`);
    }
    if (beforeState.position && !positions.some((position) => Math.abs(position.quantity) > 1e-12 && stateMatches(position))) {
        throw new Error("QUALITY102_PREFLIGHT_STATE_POSITION_NOT_ON_EXCHANGE");
    }
    const managedProtectiveOrders = findQ102PreflightAllManagedProtectiveOrders(openOrders, positions);
    const managedProtectiveOrderSet = new Set(managedProtectiveOrders);
    const unmanagedOpenOrders = openOrders.filter((order) => !managedProtectiveOrderSet.has(order));
    if (unmanagedOpenOrders.length > 0) throw new Error("QUALITY102_PREFLIGHT_OPEN_ORDER_CONFLICT");
    const quotes = await Promise.all(config.symbols.map(async (symbol) => {
        const quote = await executor.getMarketQuote(symbol);
        return { symbol, quote };
    }));
    const quotesNow = Date.now();
    for (const { symbol, quote } of quotes) {
        if (quote.symbol.toUpperCase() !== symbol || !(quote.bidPrice > 0) || !(quote.askPrice > 0) || quote.askPrice < quote.bidPrice || !(quote.midPrice > 0) || !Number.isFinite(quote.updatedAt) || quote.updatedAt <= 0 || quote.updatedAt > quotesNow || quotesNow - quote.updatedAt > config.maxDataAgeMs) {
            throw new Error(`QUALITY102_PREFLIGHT_QUOTE_INVALID:${symbol}`);
        }
    }
    const history = shouldRunQuality102CausalV1PreflightHistoryCheck(env)
        ? await marketData.load()
        : undefined;
    const afterStateFile = await stateFileSnapshot(config.statePath);
    if (beforeStateFile !== afterStateFile) throw new Error("QUALITY102_PREFLIGHT_STATE_CHANGED");
    return {
        status: "QUALITY102_CAUSAL_V1_READ_ONLY_PREFLIGHT_PASS",
        mode: config.mode,
        selectorMode: config.selectorMode,
        highVolSymbols: config.highVolSymbols,
        symbols: config.symbols,
        historySymbols: history ? Object.keys(history.candlesBySymbol).sort() : [],
        historicalHistoryCheck: history ? "PASS" : "DEFERRED_TO_DAEMON_FIRST_TICK",
        statePath: config.statePath,
        stateExists: await stateFileExists(config.statePath),
        accountAsset: account.asset,
        positionCount: positions.length,
        openOrderCount: openOrders.length,
        managedProtectiveOrderCount: managedProtectiveOrders.length,
        quality102Position: beforeState.position?.symbol,
        quality102Pending: Boolean(beforeState.pending),
        gross: {
            quality102: config.maximumGross,
            crypto: config.cryptoGrossCap,
            total: config.totalGrossCap,
        },
        ordersSent: 0,
        cancelSent: 0,
        positionChangesSent: 0,
        stateChanged: false,
        syntheticOrders: 0,
        testOrders: 0,
    };
}

export function buildQuality102CausalV1Runner(env: NodeJS.ProcessEnv = process.env) {
    const config = resolveQuality102CausalV1LiveConfig(env);
    assertQuality102CausalV1LiveActivation(config);
    const client = createClient(env, config.runtimeCommitSha);
    if (config.mode === "LIVE" && !client.hasTradingCredentials()) throw new Error("QUALITY102_CAUSAL_V1_LIVE_CREDENTIALS_REQUIRED");
    const aster = new AsterDirectTradeExecutor(client, {
        exchangeInfoTtlMs: numberEnv(env, "ASTER_EXCHANGE_INFO_TTL_MS", 15 * 60_000),
        reconciliationAttempts: numberEnv(env, "ASTER_ORDER_RECONCILE_ATTEMPTS", 6),
        reconciliationDelayMs: numberEnv(env, "ASTER_ORDER_RECONCILE_DELAY_MS", 1500),
    });
    const executor = config.mode === "PAPER"
        ? new SignedPaperDirectTradeExecutor(aster, {
            statePath: resolve(config.stateRoot, "paper-portfolio.json"),
            initialBalanceUsd: numberEnv(env, "QUALITY102_CAUSAL_V1_PAPER_INITIAL_BALANCE_USD", 1000),
            feeBpsPerSide: numberEnv(env, "QUALITY102_CAUSAL_V1_PAPER_FEE_BPS_PER_SIDE", 6),
            maxGross: config.totalGrossCap,
        })
        : aster;
    const sharedV12Adapter = config.mode === "LIVE"
        ? new V12AsterLiveAdapter(client, {
            maxSlippageBps: config.maxSlippageBps,
            reconciliationAttempts: numberEnv(env, "ASTER_ORDER_RECONCILE_ATTEMPTS", 6),
            reconciliationDelayMs: numberEnv(env, "ASTER_ORDER_RECONCILE_DELAY_MS", 1500),
            readRequestSpacingMs: numberEnv(env, "V12_X1_ALL_REQUEST_SPACING_MS", 100),
        })
        : undefined;
    const runner = new Quality102CausalV1Runner({
        marketData: new Quality102CausalV1AsterMarketDataProvider(client, {
            symbols: config.symbols,
            historyHours: config.historyHours,
            pageLimit: config.historyPageLimit,
            cacheTtlMs: numberEnv(env, "QUALITY102_CAUSAL_V1_HISTORY_CACHE_TTL_MS", 5 * 60_000),
            cachePath: config.historyCachePath,
            requestSpacingMs: numberEnv(env, "QUALITY102_CAUSAL_V1_HISTORY_REQUEST_SPACING_MS", 100),
            rateLimitAttempts: numberEnv(env, "QUALITY102_CAUSAL_V1_HISTORY_RATE_LIMIT_ATTEMPTS", 3),
        }),
        executor,
        residentStopGateway: config.mode === "LIVE" ? new AsterResidentStopGateway(client) : undefined,
        stateStore: new FileQuality102CausalV1StateStore(config.statePath, config.mode, config.expectedRuntimeCommitSha),
        lock: new FileAccountOrderLock(config.accountLockPath, numberEnv(env, "DISDEX_ACCOUNT_LOCK_LEASE_MS", 120_000)),
        signalBuilder: (input) => buildQuality102CausalV4Signal(input, { highVolSymbols: config.highVolSymbols }),
        decisionObserver: async ({ history, decisionTs }) => {
            const snapshot = buildQuality102CausalV4DecisionSnapshot({
                history,
                decisionTs,
                highVolSymbols: config.highVolSymbols,
                symbols: config.symbols,
                runtimeCommitSha: config.runtimeCommitSha,
            });
            const target = resolve(config.stateRoot, "decision-snapshot.json");
            const temporary = `${target}.${process.pid}.tmp`;
            await writeFile(temporary, JSON.stringify(snapshot, null, 2) + "\n", { encoding: "utf8", mode: 0o600 });
            await rename(temporary, target);
        },
        config: {
            residentStopRequired: config.mode === "LIVE",
            profitFloorEnabled: config.profitFloorEnabled,
            adoptedExitPoliciesEnabled: config.adoptedExitPoliciesEnabled,
            mode: config.mode,
            enabled: config.enabled,
            liveTradingEnabled: config.liveTradingEnabled,
            liveExecutionEnabled: config.liveExecutionEnabled,
            operatorArmed: config.operatorArmed,
            runtimeCommitSha: config.runtimeCommitSha,
            expectedRuntimeCommitSha: config.expectedRuntimeCommitSha,
            symbols: config.symbols,
            maximumGross: config.maximumGross,
            cryptoGrossCap: config.cryptoGrossCap,
            totalGrossCap: config.totalGrossCap,
            maximumPositions: config.maximumPositions,
            maxSlippageBps: config.maxSlippageBps,
            minimumOrderNotionalUsd: config.minimumOrderNotionalUsd,
            maximumEntryDelayMs: config.maximumEntryDelayMs,
            maximumDailyLossPct: config.maximumDailyLossPct,
            maxDataAgeMs: config.maxDataAgeMs,
            killSwitchPath: config.killSwitchPath,
            sharedDailyRiskPath: config.sharedDailyRiskPath,
            portfolioDdGovernorPath: config.portfolioDdGovernorPath,
            v12DynamicAdapter: sharedV12Adapter,
            v12StatePath: String(env.V12_X1_ALL_STATE_PATH || "/var/lib/disdex/v12-x1-all/runner.json").trim(),
            accountScope: "ASTER_FUTURES",
        },
    });
    return { config, runner };
}

async function main(): Promise<void> {
    if (process.argv.includes("--preflight")) {
        try {
            const result = await runQuality102CausalV1ReadOnlyPreflight();
            console.log(JSON.stringify(result));
        } catch (error) {
            const deferred = classifyQ102PreflightRateBudgetDeferral(error);
            if (!deferred) throw error;
            console.log(JSON.stringify(deferred));
        }
        return;
    }
    const built = buildQuality102CausalV1Runner();
    console.log(JSON.stringify({
        event: "quality102-causal-v1-runner-start",
        strategyId: QUALITY102_CAUSAL_V1.strategyId,
        mode: built.config.mode,
        enabled: built.config.enabled,
        selectorMode: built.config.selectorMode,
        highVolSymbols: built.config.highVolSymbols,
        symbols: built.config.symbols,
        runtimeCommitSha: built.config.runtimeCommitSha,
        quality102GrossCap: built.config.maximumGross,
        cryptoGrossCap: built.config.cryptoGrossCap,
        totalGrossCap: built.config.totalGrossCap,
        historicalSelectorParity: false,
        causalV4SelectorImplemented: QUALITY102_CAUSAL_V4_CAPABILITIES.selectorImplemented,
        brkLiveEnabled: true,
        ordersSent: 0,
    }));
    const daemon = process.argv.includes("--daemon");
    const delay = createInterruptibleDelay();
    let stopping = false;
    const stop = () => { stopping = true; delay.interrupt(); };
    process.on("SIGINT", stop);
    process.on("SIGTERM", stop);
    do {
        const result = await built.runner.tick();
        console.log(JSON.stringify({ timestamp: new Date().toISOString(), ...result }));
        if (!daemon || stopping || result.status === "manual-review") {
            if (result.status === "manual-review") process.exitCode = 2;
            break;
        }
        const now = Date.now();
        const boundaryDelayMs = Math.min(30_000, Math.max(1_000, numberEnv(process.env, "QUALITY102_CAUSAL_V1_BOUNDARY_DELAY_MS", 5_000)));
        const lockRetryMs = Math.min(30_000, Math.max(1_000, numberEnv(process.env, "QUALITY102_CAUSAL_V1_LOCK_RETRY_MS", 5_000)));
        await delay.wait(nextQuality102DaemonWaitMs(result.status, now, boundaryDelayMs, lockRetryMs, result.message));
    } while (!stopping);
}

if (import.meta.url === `file://${process.argv[1]}`) {
    main().catch((error) => {
        console.error(JSON.stringify({
            level: "fatal",
            strategyId: QUALITY102_CAUSAL_V1.strategyId,
            status: "QUALITY102_CAUSAL_V1_FAIL_CLOSED",
            message: isAsterDepositRequirementError(error)
                ? "ASTER_FUTURES_V3_DEPOSIT_REQUIREMENT_5050_FAIL_CLOSED"
                : error instanceof Error ? error.message : String(error),
            ordersSent: 0,
            syntheticOrders: 0,
            testOrders: 0,
        }));
        process.exitCode = 1;
    });
}
