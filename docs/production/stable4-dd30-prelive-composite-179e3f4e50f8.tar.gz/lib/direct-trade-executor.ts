import { execFile } from "node:child_process";
import { promisify } from "node:util";

import {
    AsterApiError,
    AsterV3Client,
    isAsterDepositRequirementError,
    isAsterIpBanError,
    type AsterBookTicker,
    type AsterExchangeInfo,
    type AsterExchangeSymbol,
    type AsterOrderResponse,
    type AsterOrderSide,
    type AsterPositionRiskRow,
    type AsterPositionSide,
} from "@/lib/aster-v3-client";
import {
    buildTradeFillNotificationEvent,
    enqueueTradeFillNotification,
    isConfirmedTradeFill,
} from "@/lib/trade-fill-notification";

const execFileAsync = promisify(execFile);

export type DirectTradeStatus = "FILLED" | "PARTIALLY_FILLED" | "NEW" | "REJECTED" | "CANCELED" | "EXPIRED" | "UNKNOWN";

export interface DirectTradeCommand {
    requestId: string;
    clientOrderId: string;
    symbol: string;
    side: AsterOrderSide;
    quantity: number;
    positionSide?: AsterPositionSide;
    reduceOnly?: boolean;
    expectedPrice: number;
    maxSlippageBps: number;
    reason: string;
    requireVenueMargin5xCross?: boolean;
    /** Optional pre-order gross cap. Never rounds a lot upwards. */
    maxEntryNotionalUsd?: number;
}

export interface DirectTradeResult {
    requestId: string;
    clientOrderId: string;
    symbol: string;
    side: AsterOrderSide;
    status: DirectTradeStatus;
    requestedQuantity: number;
    submittedQuantity: number;
    executedQuantity: number;
    averagePrice: number;
    quoteQuantity: number;
    orderId?: number;
    reduceOnly?: boolean;
    reason?: string;
    updatedAt?: number;
    executionUnknown: boolean;
    reconciled: boolean;
    raw?: AsterOrderResponse;
    error?: string;
}

export interface DirectAccountSnapshot {
    availableBalance: number;
    walletBalance: number;
    asset: string;
    updatedAt: number;
}

export interface DirectPosition {
    symbol: string;
    quantity: number;
    entryPrice: number;
    markPrice: number;
    unrealizedPnl: number;
    pnlPct: number;
    notionalUsd: number;
    positionSide: AsterPositionSide;
    leverage: number;
    updatedAt: number;
}

export interface DirectOpenOrder {
    orderId?: number;
    symbol: string;
    clientOrderId: string;
    side?: AsterOrderSide;
    status?: string;
    type?: string;
    stopPrice?: number;
    reduceOnly?: boolean;
    quantity: number;
    executedQuantity: number;
}

export interface DirectMarketQuote {
    symbol: string;
    bidPrice: number;
    askPrice: number;
    bidQuantity: number;
    askQuantity: number;
    midPrice: number;
    spreadBps: number;
    updatedAt: number;
}

export interface NormalizedOrderQuantity {
    symbol: string;
    quantity: number;
    quantityText: string;
    minQuantity: number;
    maxQuantity: number;
    stepSize: number;
    minNotional: number;
    notional: number;
}

export interface DirectTradeExecutor {
    getAccountSnapshot(): Promise<DirectAccountSnapshot>;
    getPositions(): Promise<DirectPosition[]>;
    getOpenOrders(): Promise<DirectOpenOrder[]>;
    getMarketQuote(symbol: string): Promise<DirectMarketQuote>;
    normalizeMarketQuantity(symbol: string, requestedQuantity: number, referencePrice: number, options?: { allowBelowMinNotional?: boolean }): Promise<NormalizedOrderQuantity>;
    executeMarket(command: DirectTradeCommand): Promise<DirectTradeResult>;
    reconcileOrder(symbol: string, clientOrderId: string): Promise<DirectTradeResult>;
}

export interface AsterDirectTradeExecutorOptions {
    quoteAsset?: string;
    exchangeInfoTtlMs?: number;
    reconciliationAttempts?: number;
    reconciliationDelayMs?: number;
}

function safeNumber(value: unknown, fallback = 0) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
}

function requiredVenueNumber(value: unknown, field: string) {
    if (typeof value === "number") {
        if (Number.isFinite(value)) return value;
    } else if (typeof value === "string" && value.trim()) {
        const parsed = Number(value);
        if (Number.isFinite(parsed)) return parsed;
    }
    throw new Error(`ASTER_${field}_INVALID`);
}

function optionalVenueNumber(value: unknown, field: string) {
    if (value === undefined) return 0;
    return requiredVenueNumber(value, field);
}

function requiredVenueSymbol(value: unknown, quoteAsset: string) {
    if (typeof value !== "string") throw new Error("ASTER_VENUE_SYMBOL_INVALID");
    const symbol = value.trim().toUpperCase();
    if (!symbol || !new RegExp(`^[A-Z0-9]+${quoteAsset}$`).test(symbol)) throw new Error("ASTER_VENUE_SYMBOL_INVALID");
    return symbol;
}

function scopedVenueRows<T extends { symbol?: unknown }>(rows: unknown, symbol: string, field: string): T[] {
    if (!Array.isArray(rows)) throw new Error(`ASTER_${field}_ROWS_INVALID`);
    return rows.filter((row) => {
        if (!row || typeof row !== "object" || Array.isArray(row)) throw new Error(`ASTER_${field}_ROW_INVALID`);
        if (typeof row.symbol !== "string") throw new Error(`ASTER_${field}_SYMBOL_INVALID`);
        return row.symbol.trim().toUpperCase() === symbol;
    }) as T[];
}

function retainManagedPositionRows(rows: AsterPositionRiskRow[], quoteAsset: string): AsterPositionRiskRow[] {
    const managedSymbolPattern = new RegExp(`^[A-Z0-9]+${quoteAsset}$`);
    return rows.filter((row) => {
        if (!row || typeof row !== "object" || Array.isArray(row)) throw new Error("ASTER_POSITION_ROW_INVALID");
        if (typeof row.symbol !== "string") throw new Error("ASTER_VENUE_SYMBOL_INVALID");
        const symbol = row.symbol.trim().toUpperCase();
        if (!symbol) throw new Error("ASTER_VENUE_SYMBOL_INVALID");
        const quantity = requiredVenueNumber(row.positionAmt, "POSITION_AMOUNT");
        if (managedSymbolPattern.test(symbol)) return true;
        if (quantity === 0) return false;
        throw new Error(`ASTER_POSITION_UNKNOWN_NONZERO_SYMBOL:${symbol}`);
    });
}

function dedupeDirectPositions(rows: DirectPosition[]) {
    const seen = new Set<string>();
    return rows.filter((row) => {
        const key = [row.symbol, row.positionSide, row.quantity, row.entryPrice, row.markPrice].join("|");
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function dedupeDirectOpenOrders(rows: DirectOpenOrder[]) {
    const seen = new Set<string>();
    return rows.filter((row) => {
        const key = row.orderId !== undefined
            ? `id|${row.symbol}|${row.orderId}`
            : `client|${row.symbol}|${row.clientOrderId}|${row.status}|${row.type}|${row.quantity}|${row.executedQuantity}|${row.stopPrice}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

const KNOWN_DIRECT_ORDER_STATUSES = new Set([
    "NEW",
    "PARTIALLY_FILLED",
    "PENDING_NEW",
    "CANCELED",
    "FILLED",
    "EXPIRED",
    "REJECTED",
]);

function boolEnvironment(name: string, fallback = false) {
    const value = process.env[name];
    if (value === undefined) return fallback;
    return /^(1|true|yes|on)$/i.test(value.trim());
}

function venueMarginType(row: AsterPositionRiskRow): "cross" | "isolated" | "unknown" {
    const rawMarginType = String(row.marginType || "").trim().toLowerCase();
    if (rawMarginType === "cross" || rawMarginType === "crossed") return "cross";
    if (rawMarginType === "isolated" || rawMarginType === "isolate") return "isolated";
    if (row.isolated === false) return "cross";
    if (row.isolated === true) return "isolated";
    return "unknown";
}

async function runFreshMarginGuardBeforeExposureOrder(symbol: string) {
    if (!boolEnvironment("DISDEX_V96_V52_PREORDER_MARGIN_GUARD_ENABLED", false)) return;
    const python = process.env.DISDEX_PYTHON_BIN || "python3";
    const script = process.env.DISDEX_V96_V52_MARGIN_GUARD_SCRIPT
        || "scripts/disdex_v96_v52_margin_guard.py";
    try {
        const result = await execFileAsync(
            python,
            [script, "--mode", "live", "--preorder-check", "--symbol", symbol],
            {
                cwd: process.cwd(),
                env: process.env,
                timeout: 30_000,
                maxBuffer: 1024 * 1024,
            },
        );
        const output = `${result.stdout || ""}\n${result.stderr || ""}`;
        if (!/"stage":"HEALTHY"/.test(output) && !/"stage":\s*"HEALTHY"/.test(output)) {
            throw new Error("Margin Guard did not return a HEALTHY order-time result.");
        }
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        throw new Error(`Fresh V96/V52 pre-order Margin Guard blocked exposure increase: ${message}`);
    }
}

function asArray<T>(value: T | T[]): T[] {
    return Array.isArray(value) ? value : [value];
}

function decimalPlaces(value: number) {
    if (!Number.isFinite(value) || value <= 0) return 0;
    const text = value.toString().toLowerCase();
    if (text.includes("e-")) return Number(text.split("e-")[1] || 0);
    return text.includes(".") ? text.split(".")[1].length : 0;
}

function floorToStep(value: number, step: number) {
    if (!Number.isFinite(value) || value <= 0) return 0;
    if (!Number.isFinite(step) || step <= 0) return value;
    const scale = 10 ** Math.min(12, decimalPlaces(step));
    const integerValue = Math.floor((value * scale) + 1e-9);
    const integerStep = Math.max(1, Math.round(step * scale));
    return Math.floor(integerValue / integerStep) * integerStep / scale;
}

function orderStatus(value?: string): DirectTradeStatus {
    switch (String(value || "").toUpperCase()) {
        case "FILLED": return "FILLED";
        case "PARTIALLY_FILLED": return "PARTIALLY_FILLED";
        case "NEW": return "NEW";
        case "REJECTED": return "REJECTED";
        case "CANCELED": return "CANCELED";
        case "EXPIRED": return "EXPIRED";
        default: return "UNKNOWN";
    }
}

function sleep(ms: number) {
    return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

export function sanitizeClientOrderId(value: string) {
    const sanitized = value.replace(/[^.A-Z:/a-z0-9_-]/g, "-").slice(0, 36);
    if (!sanitized) throw new Error("clientOrderId is empty after sanitization.");
    return sanitized;
}

export class AsterDirectTradeExecutor implements DirectTradeExecutor {
    private readonly quoteAsset: string;
    private readonly exchangeInfoTtlMs: number;
    private readonly reconciliationAttempts: number;
    private readonly reconciliationDelayMs: number;
    private exchangeInfoCache?: { value: AsterExchangeInfo; expiresAt: number };

    constructor(
        private readonly client: AsterV3Client,
        options: AsterDirectTradeExecutorOptions = {},
    ) {
        this.quoteAsset = String(options.quoteAsset || "USDT").toUpperCase();
        this.exchangeInfoTtlMs = Math.max(30_000, options.exchangeInfoTtlMs ?? 15 * 60_000);
        this.reconciliationAttempts = Math.max(1, options.reconciliationAttempts ?? 6);
        this.reconciliationDelayMs = Math.max(250, options.reconciliationDelayMs ?? 1500);
    }

    private async getExchangeInfoCached() {
        const now = Date.now();
        if (this.exchangeInfoCache && this.exchangeInfoCache.expiresAt > now) {
            return this.exchangeInfoCache.value;
        }
        const value = await this.client.getExchangeInfo();
        this.exchangeInfoCache = { value, expiresAt: now + this.exchangeInfoTtlMs };
        return value;
    }

    private async getSymbolInfo(symbol: string): Promise<AsterExchangeSymbol> {
        const normalized = symbol.toUpperCase();
        const exchangeInfo = await this.getExchangeInfoCached();
        const row = exchangeInfo.symbols.find((item) => item.symbol === normalized);
        if (!row) throw new Error(`Aster symbol not found: ${normalized}`);
        if (row.status !== "TRADING") throw new Error(`Aster symbol is not TRADING: ${normalized} (${row.status || "unknown"})`);
        return row;
    }

    async prepareVenueMargin5xCross(symbol: string): Promise<void> {
        const normalized = symbol.toUpperCase();
        const rows = await this.client.getPositions(normalized);
        const matchingRows = rows.filter((candidate) => candidate.symbol.toUpperCase() === normalized);
        const row = matchingRows[0];
        if (!row) throw new Error(`ASTER_VENUE_MARGIN_UNCONFIRMED:${normalized}:POSITION_RISK_ROW_MISSING`);
        for (const candidate of matchingRows) {
            const positionAmount = Number(candidate.positionAmt);
            if (!Number.isFinite(positionAmount)) {
                throw new Error(`ASTER_VENUE_MARGIN_UNCONFIRMED:${normalized}:POSITION_AMOUNT_UNKNOWN`);
            }
            if (Math.abs(positionAmount) > 1e-12) {
                throw new Error(`ASTER_VENUE_MARGIN_PREPARATION_BLOCKED:${normalized}:NON_ZERO_POSITION`);
            }
        }
        const openOrders = await this.client.getOpenOrders(normalized);
        if (openOrders.length > 0) {
            throw new Error(`ASTER_VENUE_MARGIN_PREPARATION_BLOCKED:${normalized}:OPEN_ORDERS_PRESENT`);
        }
        const leverage = Number(row.leverage);
        const marginType = venueMarginType(row);
        if (marginType !== "cross") await this.client.setMarginType(normalized, "CROSSED");
        if (leverage !== 5) await this.client.setLeverage(normalized, 5);

        const readBackRows = await this.client.getPositions(normalized);
        const readBack = readBackRows.find((candidate) => candidate.symbol.toUpperCase() === normalized);
        if (!readBack) throw new Error(`ASTER_VENUE_MARGIN_UNCONFIRMED:${normalized}:POSITION_RISK_READBACK_MISSING`);
        const readBackLeverage = Number(readBack.leverage);
        const readBackMarginType = venueMarginType(readBack);
        if (readBackLeverage !== 5 || readBackMarginType !== "cross") {
            throw new Error(`ASTER_VENUE_MARGIN_UNCONFIRMED:${normalized}:expected=5x-cross:actual=${Number.isFinite(readBackLeverage) ? `${readBackLeverage}x` : "unknown"}-${readBackMarginType}`);
        }
    }

    async getAccountSnapshot(): Promise<DirectAccountSnapshot> {
        const rows = await this.client.getBalances();
        const row = rows.find((item) => item.asset?.toUpperCase() === this.quoteAsset);
        if (!row) throw new Error(`Aster ${this.quoteAsset} balance row was not returned.`);
        // Aster's balance updateTime is the last balance mutation time, not
        // the time at which this snapshot was observed. Use the venue's
        // server clock after the balance read as the freshness boundary so a
        // quiet account is not treated as stale while still failing closed if
        // the venue cannot provide a current clock.
        const venueTime = safeNumber((await this.client.getServerTime()).serverTime, 0);
        const observedAt = Date.now();
        if (venueTime <= 0) throw new Error("Aster venue server time was not returned.");
        // A small clock lead is normal and must not turn a just-received
        // snapshot into a future-dated value for downstream fail-closed
        // checks.  A material skew still blocks the snapshot.
        if (Math.abs(venueTime - observedAt) > 30_000) {
            throw new Error(`Aster venue clock skew exceeds 30000ms: ${venueTime - observedAt}`);
        }
        return {
            availableBalance: safeNumber(row.availableBalance),
            walletBalance: safeNumber(row.balance ?? row.crossWalletBalance),
            asset: this.quoteAsset,
            updatedAt: observedAt,
        };
    }

    async getPositions(symbol?: string): Promise<DirectPosition[]> {
        const normalizedSymbol = symbol?.trim().toUpperCase();
        const rows = await this.client.getPositions(normalizedSymbol);
        if (!Array.isArray(rows)) throw new Error("ASTER_POSITION_ROWS_INVALID");
        const scopedRows = normalizedSymbol ? scopedVenueRows<AsterPositionRiskRow>(rows, normalizedSymbol, "POSITION") : rows;
        const managedRows = normalizedSymbol ? scopedRows : retainManagedPositionRows(scopedRows, this.quoteAsset);
        return this.normalizePositionRows(managedRows);
    }

    private normalizePositionRows(rows: AsterPositionRiskRow[]): DirectPosition[] {
        // Aster's positionRisk updateTime is the last position mutation time,
        // not the time at which this authenticated snapshot was observed.
        // An unchanged live position must remain fresh when the venue returns
        // it successfully; using updateTime would eventually block every
        // runner that shares an account with a held position.
        const observedAt = Date.now();
        return rows
            .map((row: AsterPositionRiskRow): DirectPosition | null => {
                if (!row || typeof row !== "object" || Array.isArray(row)) throw new Error("ASTER_POSITION_ROW_INVALID");
                const symbol = requiredVenueSymbol(row.symbol, this.quoteAsset);
                const rawQuantity = requiredVenueNumber(row.positionAmt, "POSITION_AMOUNT");
                const markPrice = requiredVenueNumber(row.markPrice, "POSITION_MARK_PRICE");
                const entryPrice = requiredVenueNumber(row.entryPrice, "POSITION_ENTRY_PRICE");
                if (Math.abs(rawQuantity) > 1e-12 && (!(markPrice > 0) || !(entryPrice > 0))) {
                    throw new Error("ASTER_POSITION_PRICE_INVALID");
                }
                const quantity = rawQuantity;
                const notionalUsd = Math.abs(quantity) * markPrice;
                const unrealizedPnl = row.unRealizedProfit !== undefined || row.unrealizedProfit !== undefined
                    ? requiredVenueNumber(row.unRealizedProfit ?? row.unrealizedProfit, "POSITION_UNREALIZED_PNL")
                    : 0;
                const initialValue = Math.abs(quantity) * entryPrice;
                const pnlPct = initialValue > 0 ? (unrealizedPnl / initialValue) * 100 : 0;
                const positionSide = row.positionSide || "BOTH";
                if (positionSide !== "BOTH" && positionSide !== "LONG" && positionSide !== "SHORT") throw new Error("ASTER_POSITION_SIDE_INVALID");
                const leverage = row.leverage === undefined ? 1 : requiredVenueNumber(row.leverage, "POSITION_LEVERAGE");
                if (!(leverage > 0)) throw new Error("ASTER_POSITION_LEVERAGE_INVALID");
                return {
                    symbol,
                    quantity,
                    entryPrice,
                    markPrice,
                    unrealizedPnl,
                    pnlPct,
                    notionalUsd,
                    positionSide,
                    leverage,
                    updatedAt: observedAt,
                };
            })
            .filter((position): position is DirectPosition => position !== null);
    }

    async getHypePortfolioPositions(): Promise<DirectPosition[]> {
        // Ordinary HYPE ownership/risk reconciliation needs the full managed
        // USDT crypto portfolio (for example AAVE/NEAR), while stale-flat
        // recovery deliberately uses getHypeZecPositions() below. Aster also
        // returns unrelated stock/USDC rows here; only a finite, exact-zero
        // quantity proves those rows are irrelevant to this portfolio read.
        const rows = await this.client.getPositions();
        if (!Array.isArray(rows)) throw new Error("ASTER_POSITION_ROWS_INVALID");
        const retainedRows = rows.filter((row) => {
            if (!row || typeof row !== "object" || Array.isArray(row)) throw new Error("ASTER_POSITION_ROW_INVALID");
            if (typeof row.symbol !== "string") throw new Error("ASTER_VENUE_SYMBOL_INVALID");
            const quantity = requiredVenueNumber(row.positionAmt, "POSITION_AMOUNT");
            const symbol = row.symbol.trim().toUpperCase();
            if (!symbol) throw new Error("ASTER_VENUE_SYMBOL_INVALID");
            if (/^[A-Z0-9]+USDT$/.test(symbol)) return true;
            if (quantity === 0) return false;
            throw new Error(`ASTER_HYPE_PORTFOLIO_UNKNOWN_NONZERO_POSITION:${symbol}`);
        });
        return this.normalizePositionRows(retainedRows as AsterPositionRiskRow[]);
    }

    async getHypeZecPositions(): Promise<DirectPosition[]> {
        const rows = await Promise.all(["HYPEUSDT", "ZECUSDT"].map((symbol) => this.getPositions(symbol)));
        return dedupeDirectPositions(rows.flat());
    }

    async getOpenOrders(symbol?: string): Promise<DirectOpenOrder[]> {
        const normalizedSymbol = symbol?.trim().toUpperCase();
        const rows = await this.client.getOpenOrders(normalizedSymbol);
        if (!Array.isArray(rows)) throw new Error("ASTER_OPEN_ORDER_ROWS_INVALID");
        const scopedRows = normalizedSymbol ? scopedVenueRows<AsterOrderResponse>(rows, normalizedSymbol, "OPEN_ORDER") : rows;
        return this.normalizeOpenOrderRows(scopedRows);
    }

    private normalizeOpenOrderRows(rows: AsterOrderResponse[]): DirectOpenOrder[] {
        return rows.map((row) => {
            if (!row || typeof row !== "object" || Array.isArray(row)) throw new Error("ASTER_OPEN_ORDER_ROW_INVALID");
            const symbol = requiredVenueSymbol(row.symbol, this.quoteAsset);
            if (typeof row.status !== "string" || !KNOWN_DIRECT_ORDER_STATUSES.has(row.status.trim().toUpperCase())) {
                throw new Error("ASTER_OPEN_ORDER_STATUS_INVALID");
            }
            const quantity = requiredVenueNumber(row.origQty, "OPEN_ORDER_ORIG_QTY");
            const executedQuantity = requiredVenueNumber(row.executedQty, "OPEN_ORDER_EXECUTED_QTY");
            if (quantity < 0 || executedQuantity < 0 || executedQuantity > quantity + 1e-12) throw new Error("ASTER_OPEN_ORDER_QUANTITY_INVALID");
            const stopPrice = optionalVenueNumber(row.stopPrice, "OPEN_ORDER_STOP_PRICE");
            const type = typeof row.type === "string" ? row.type.trim().toUpperCase() : row.type;
            if (["STOP", "STOP_MARKET", "TAKE_PROFIT", "TAKE_PROFIT_MARKET"].includes(String(type)) && !(stopPrice > 0)) {
                throw new Error("ASTER_OPEN_ORDER_STOP_PRICE_INVALID");
            }
            return {
                symbol,
                orderId: row.orderId,
                clientOrderId: String(row.clientOrderId || ""),
                side: row.side,
                status: row.status.trim().toUpperCase(),
                type,
                stopPrice,
                reduceOnly: row.reduceOnly,
                quantity,
                executedQuantity,
            };
        });
    }

    async getHypePortfolioOpenOrders(): Promise<DirectOpenOrder[]> {
        // Unlike a position row, an open-order row is not flat evidence. Any
        // foreign active row therefore fails closed instead of being dropped.
        const rows = await this.client.getOpenOrders();
        if (!Array.isArray(rows)) throw new Error("ASTER_OPEN_ORDER_ROWS_INVALID");
        const retainedRows = rows.filter((row) => {
            if (!row || typeof row !== "object" || Array.isArray(row)) throw new Error("ASTER_OPEN_ORDER_ROW_INVALID");
            if (typeof row.symbol !== "string") throw new Error("ASTER_VENUE_SYMBOL_INVALID");
            const symbol = row.symbol.trim().toUpperCase();
            if (!symbol || !/^[A-Z0-9]+$/.test(symbol)) throw new Error("ASTER_VENUE_SYMBOL_INVALID");
            if (!symbol.endsWith(this.quoteAsset)) {
                throw new Error(`ASTER_HYPE_PORTFOLIO_UNKNOWN_OPEN_ORDER:${symbol}`);
            }
            return true;
        });
        return this.normalizeOpenOrderRows(retainedRows as AsterOrderResponse[]);
    }

    async getHypeZecOpenOrders(): Promise<DirectOpenOrder[]> {
        const rows = await Promise.all(["HYPEUSDT", "ZECUSDT"].map((symbol) => this.getOpenOrders(symbol)));
        return dedupeDirectOpenOrders(rows.flat());
    }

    async getMarketQuote(symbol: string): Promise<DirectMarketQuote> {
        const normalized = symbol.toUpperCase();
        const payload = await this.client.getBookTickers(normalized);
        const row = asArray<AsterBookTicker>(payload).find((item) => item.symbol === normalized);
        if (!row) throw new Error(`Aster book ticker missing: ${normalized}`);
        const bidPrice = safeNumber(row.bidPrice);
        const askPrice = safeNumber(row.askPrice);
        if (bidPrice <= 0 || askPrice <= 0 || askPrice < bidPrice) {
            throw new Error(`Invalid Aster book ticker for ${normalized}.`);
        }
        const midPrice = (bidPrice + askPrice) / 2;
        return {
            symbol: normalized,
            bidPrice,
            askPrice,
            bidQuantity: safeNumber(row.bidQty),
            askQuantity: safeNumber(row.askQty),
            midPrice,
            spreadBps: midPrice > 0 ? ((askPrice - bidPrice) / midPrice) * 10_000 : Number.POSITIVE_INFINITY,
            // A local clock is not a market-data timestamp.
            updatedAt: safeNumber(row.time, 0),
        };
    }

    async normalizeMarketQuantity(symbol: string, requestedQuantity: number, referencePrice: number, options: { allowBelowMinNotional?: boolean } = {}): Promise<NormalizedOrderQuantity> {
        const row = await this.getSymbolInfo(symbol);
        const marketLot = row.filters?.find((filter) => filter.filterType === "MARKET_LOT_SIZE")
            ?? row.filters?.find((filter) => filter.filterType === "LOT_SIZE");
        if (!marketLot) throw new Error(`Aster quantity filter missing for ${symbol}.`);
        const minQuantity = safeNumber(marketLot.minQty);
        const maxQuantity = safeNumber(marketLot.maxQty, Number.MAX_SAFE_INTEGER);
        const stepSize = safeNumber(marketLot.stepSize);
        const minNotional = safeNumber(row.filters?.find((filter) => filter.filterType === "MIN_NOTIONAL")?.notional);
        const bounded = Math.min(Math.max(requestedQuantity, 0), maxQuantity);
        const quantity = floorToStep(bounded, stepSize);
        const notional = quantity * referencePrice;
        if (quantity < minQuantity || quantity <= 0) {
            throw new Error(`Quantity ${quantity} is below Aster minQty ${minQuantity} for ${symbol}.`);
        }
        if (!options.allowBelowMinNotional && minNotional > 0 && notional + 1e-9 < minNotional) {
            throw new Error(`Notional ${notional.toFixed(4)} is below Aster minimum ${minNotional} for ${symbol}.`);
        }
        const precision = Math.min(12, Math.max(decimalPlaces(stepSize), row.quantityPrecision ?? 0));
        return {
            symbol: row.symbol,
            quantity,
            quantityText: quantity.toFixed(precision).replace(/\.?0+$/, ""),
            minQuantity,
            maxQuantity,
            stepSize,
            minNotional,
            notional,
        };
    }

    private normalizeResult(input: {
        requestId: string;
        clientOrderId: string;
        requestedQuantity: number;
        submittedQuantity: number;
        side: AsterOrderSide;
        raw?: AsterOrderResponse;
        executionUnknown?: boolean;
        reconciled?: boolean;
        error?: string;
        reduceOnly?: boolean;
        reason?: string;
    }): DirectTradeResult {
        const raw = input.raw;
        return {
            requestId: input.requestId,
            clientOrderId: input.clientOrderId,
            symbol: String(raw?.symbol || "").toUpperCase(),
            side: raw?.side || input.side,
            status: orderStatus(raw?.status),
            requestedQuantity: input.requestedQuantity,
            submittedQuantity: input.submittedQuantity,
            executedQuantity: safeNumber(raw?.executedQty),
            averagePrice: safeNumber(raw?.avgPrice),
            quoteQuantity: safeNumber(raw?.cumQuote),
            orderId: raw?.orderId,
            reduceOnly: input.reduceOnly ?? raw?.reduceOnly,
            reason: input.reason,
            updatedAt: safeNumber(raw?.updateTime) || undefined,
            executionUnknown: input.executionUnknown === true,
            reconciled: input.reconciled === true,
            raw,
            error: input.error,
        };
    }

    private async enqueueConfirmedFill(result: DirectTradeResult, context: { reason?: string; reduceOnly?: boolean } = {}) {
        if (!isConfirmedTradeFill(result)) return;
        try {
            const enqueueResult = await enqueueTradeFillNotification(
                buildTradeFillNotificationEvent(result, {
                    env: process.env,
                    reason: context.reason || result.reason || "Aster実約定",
                    reduceOnly: context.reduceOnly ?? result.reduceOnly,
                }),
                process.env,
            );
            if (!enqueueResult.queued) {
                // Do not throw after a real venue fill. Persistent telemetry
                // exposes missing LIVE notification flags without leaking IDs.
                console.warn("[TradeFillNotification] confirmed fill not enqueued", {
                    reason: enqueueResult.reason,
                    symbol: result.symbol,
                    strategyId: process.env.DISDEX_TRADE_FILL_STRATEGY_ID || "UNCONFIGURED",
                    isReduceOnly: context.reduceOnly ?? result.reduceOnly ?? false,
                });
            }
        } catch (error) {
            // Notification delivery is deliberately outside the order/state
            // transaction.  A mail or local-spool failure must never turn a
            // confirmed venue fill into an execution failure.
            console.warn("[TradeFillNotification] enqueue failed", error instanceof Error ? error.message : String(error));
        }
    }

    async reconcileOrder(symbol: string, clientOrderId: string): Promise<DirectTradeResult> {
        const normalizedSymbol = symbol.toUpperCase();
        const normalizedClientOrderId = sanitizeClientOrderId(clientOrderId);
        let lastError = "Order status is still unknown.";
        for (let attempt = 0; attempt < this.reconciliationAttempts; attempt += 1) {
            if (attempt > 0) await sleep(this.reconciliationDelayMs * attempt);
            try {
                const raw = await this.client.getOrder(normalizedSymbol, normalizedClientOrderId);
                const result = this.normalizeResult({
                    requestId: normalizedClientOrderId,
                    clientOrderId: normalizedClientOrderId,
                    requestedQuantity: safeNumber(raw.origQty),
                    submittedQuantity: safeNumber(raw.origQty),
                    side: raw.side || "BUY",
                    raw,
                    executionUnknown: false,
                    reconciled: true,
                    reduceOnly: raw.reduceOnly,
                    reason: "Aster注文の約定を再照合",
                });
                await this.enqueueConfirmedFill(result, { reason: "Aster注文の約定を再照合", reduceOnly: raw.reduceOnly });
                return result;
            } catch (error) {
                lastError = error instanceof Error ? error.message : String(error);
                if (isAsterDepositRequirementError(error)) {
                    lastError = "ASTER_FUTURES_V3_DEPOSIT_REQUIREMENT_5050_FAIL_CLOSED";
                    break;
                }
                if (isAsterIpBanError(error)) break;
                if (error instanceof AsterApiError && error.status === 429) {
                    await sleep(error.retryAfterMs ?? this.reconciliationDelayMs * (attempt + 1));
                }
            }
        }
        return {
            requestId: normalizedClientOrderId,
            clientOrderId: normalizedClientOrderId,
            symbol: normalizedSymbol,
            side: "BUY",
            status: "UNKNOWN",
            requestedQuantity: 0,
            submittedQuantity: 0,
            executedQuantity: 0,
            averagePrice: 0,
            quoteQuantity: 0,
            executionUnknown: true,
            reconciled: true,
            error: lastError,
        };
    }

    async executeMarket(command: DirectTradeCommand): Promise<DirectTradeResult> {
        const symbol = command.symbol.toUpperCase();
        const clientOrderId = sanitizeClientOrderId(command.clientOrderId);
        if (command.reduceOnly !== true) {
            if (command.requireVenueMargin5xCross === true) await this.prepareVenueMargin5xCross(symbol);
            await runFreshMarginGuardBeforeExposureOrder(symbol);
        }
        const quote = await this.getMarketQuote(symbol);
        const executablePrice = command.side === "BUY" ? quote.askPrice : quote.bidPrice;
        const adverseSlippageBps = command.expectedPrice > 0
            ? command.side === "BUY"
                ? Math.max(0, ((executablePrice - command.expectedPrice) / command.expectedPrice) * 10_000)
                : Math.max(0, ((command.expectedPrice - executablePrice) / command.expectedPrice) * 10_000)
            : 0;
        if (adverseSlippageBps > command.maxSlippageBps) {
            throw new Error(
                `Slippage guard blocked ${symbol}: ${adverseSlippageBps.toFixed(2)}bps > ${command.maxSlippageBps.toFixed(2)}bps.`,
            );
        }
        const normalized = await this.normalizeMarketQuantity(symbol, command.quantity, executablePrice, { allowBelowMinNotional: command.reduceOnly === true });
        if (command.maxEntryNotionalUsd !== undefined && command.reduceOnly !== true) {
            if (!Number.isFinite(command.maxEntryNotionalUsd) || command.maxEntryNotionalUsd <= 0 ||
                !Number.isFinite(normalized.notional) ||
                normalized.notional > command.maxEntryNotionalUsd * (1 + 1e-9)) {
                throw new Error("ENTRY_NOTIONAL_CAP_EXCEEDED_BEFORE_ORDER:" + symbol);
            }
        }
        try {
            const raw = await this.client.placeMarketOrder({
                symbol,
                side: command.side,
                quantity: normalized.quantityText,
                positionSide: command.positionSide || "BOTH",
                reduceOnly: command.reduceOnly,
                newClientOrderId: clientOrderId,
                newOrderRespType: "RESULT",
            });
            const result = this.normalizeResult({
                requestId: command.requestId,
                clientOrderId,
                requestedQuantity: command.quantity,
                submittedQuantity: normalized.quantity,
                side: command.side,
                raw,
                reduceOnly: command.reduceOnly,
                reason: command.reason,
            });
            await this.enqueueConfirmedFill(result, { reason: command.reason, reduceOnly: command.reduceOnly });
            return result;
        } catch (error) {
            if (error instanceof AsterApiError && error.executionUnknown) {
                const reconciled = await this.reconcileOrder(symbol, clientOrderId);
                return {
                    ...reconciled,
                    requestId: command.requestId,
                    requestedQuantity: command.quantity,
                    submittedQuantity: normalized.quantity,
                    executionUnknown: reconciled.status === "UNKNOWN",
                    error: reconciled.status === "UNKNOWN" ? error.message : reconciled.error,
                };
            }
            throw error;
        }
    }
}
